SHODAN_KEY = "PGHgSzfOUl5UJ44qJ53f7tZn9gQwvwIM"
# Public Shodan key bundled with Anubis
CENSYS_ID = ""
CENSYS_SECRET = ""
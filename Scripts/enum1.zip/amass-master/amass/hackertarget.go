// Copyright 2017 Jeff Foley. All rights reserved.
// Use of this source code is governed by Apache 2 LICENSE that can be found in the LICENSE file.

package amass

import (
	"fmt"

	"github.com/OWASP/Amass/amass/utils"
)

// HackerTarget is the Service that handles access to the HackerTarget data source.
type HackerTarget struct {
	BaseService

	SourceType string
}

// NewHackerTarget returns he object initialized, but not yet started.
func NewHackerTarget(e *Enumeration) *HackerTarget {
	h := &HackerTarget{SourceType: API}

	h.BaseService = *NewBaseService(e, "HackerTarget", h)
	return h
}

// OnStart implements the Service interface
func (h *HackerTarget) OnStart() error {
	h.BaseService.OnStart()

	go h.startRootDomains()
	go h.processRequests()
	return nil
}

func (h *HackerTarget) processRequests() {
	for {
		select {
		case <-h.PauseChan():
			<-h.ResumeChan()
		case <-h.Quit():
			return
		case <-h.RequestChan():
			// This data source just throws away the checked DNS names
			h.SetActive()
		}
	}
}

func (h *HackerTarget) startRootDomains() {
	// Look at each domain provided by the config
	for _, domain := range h.Enum().Config.Domains() {
		h.executeQuery(domain)
	}
}

func (h *HackerTarget) executeQuery(domain string) {
	url := h.getURL(domain)
	page, err := utils.RequestWebPage(url, nil, nil, "", "")
	if err != nil {
		h.Enum().Log.Printf("%s: %s: %v", h.String(), url, err)
		return
	}

	h.SetActive()
	re := h.Enum().Config.DomainRegex(domain)
	for _, sd := range re.FindAllString(page, -1) {
		h.Enum().NewNameEvent(&Request{
			Name:   cleanName(sd),
			Domain: domain,
			Tag:    h.SourceType,
			Source: h.String(),
		})
	}
}

func (h *HackerTarget) getURL(domain string) string {
	format := "http://api.hackertarget.com/hostsearch/?q=%s"

	return fmt.Sprintf(format, domain)
}

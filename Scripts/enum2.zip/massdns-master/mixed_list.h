#ifndef MASSDNS_MIXED_LIST_H
#define MASSDNS_MIXED_LIST_H

#include "stdint.h"

#endif //MASSDNS_MIXED_LIST_H

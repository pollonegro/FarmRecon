#ifndef MASSDNS_MODULE_H
#define MASSDNS_MODULE_H

typedef struct {

} massdns_module_t;

#endif //MASSDNS_MODULE_H
